import json,random,subprocess,sys,types
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'litepcie'))
from migen import Module, run_simulation
from litepcie.frontend.ptm.sniffer import TLPFilterFormater
original=types.ModuleType('baseline')
exec(compile(subprocess.check_output(['git','-C',str(root/'litepcie'),'show','0439d6534a9e41f9605c6dbb52d926614b2fbeec:litepcie/frontend/ptm/sniffer.py'],text=True),'baseline','exec'),original.__dict__)
dut=Module();dut.submodules.old=original.TLPFilterFormater();dut.submodules.new=TLPFilterFormater()
stats={'cycles':0,'valid_cycles':0,'accepted_cycles':0}
def stimulus():
    rng=random.Random(941)
    for cycle in range(12000):
        data=rng.getrandbits(32)
        if cycle%11 in (0,1):data=(data & 0xffffff)|((0x34 if cycle%11==0 else 0x74)<<24)
        values={'data':data,'valid':rng.randrange(4)!=0,'last':rng.randrange(7)==0,'ctrl':rng.getrandbits(4)}
        ready=rng.randrange(4)!=0
        for item in (dut.old,dut.new):
            for name,value in values.items():yield getattr(item.sink,name).eq(value)
            yield item.source.ready.eq(ready)
        yield
        assert (yield dut.old.sink.ready)==(yield dut.new.sink.ready)
        assert (yield dut.old.source.valid)==(yield dut.new.source.valid)
        stats['cycles']+=1
        if (yield dut.old.source.valid):
            stats['valid_cycles']+=1
            stats['accepted_cycles']+=(yield dut.old.source.ready)
            for name in ('dat','be','first','last'):
                assert (yield getattr(dut.old.source,name))==(yield getattr(dut.new.source,name)),(cycle,name)
run_simulation(dut,stimulus())
assert stats['valid_cycles']>100
stats['passed']=True
(root/'ptm-equivalence.json').write_text(json.dumps(stats,indent=2)+'\n')
print(stats)
