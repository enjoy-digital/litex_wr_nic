#!/usr/bin/env python3
"""Run the reviewed, complete upstream images through the USB bench matrix."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'source'
LITEX = ROOT.parent / 'wr_link_20260911/litex'
os.environ['PYTHONPATH'] = str(LITEX)
sys.path[:0] = [str(LITEX), str(REPO / 'tools')]
from wr_recover import Board

config = json.loads((ROOT / 'bench.json').read_text())
state = {'passed': False, 'started_unix': time.time()}


def update(stage):
    state['stage'] = stage
    state['updated_unix'] = time.time()
    (ROOT / 'pipeline-state.json').write_text(json.dumps(state, indent=2) + '\n')
    print(stage, flush=True)


def qualify(name, master, duration, configure=False, reload=False):
    update(name)
    boards = {key: Board(key, cfg) for key, cfg in config.items()}
    slave = next(key for key in boards if key != master)
    try:
        for key, board in boards.items():
            if reload:
                boot = board.reload(ROOT / (name + '-' + key + '-boot'))
                if '13527cd6' not in boot['version']:
                    raise RuntimeError(key + ': loaded firmware is not the reviewed upstream revision')
            else:
                board.start_server(ROOT / (name + '-' + key + '-jtag.log'))
        cmd = [sys.executable, str(REPO / 'tools/wr_qualify.py'),
               '--duration', str(duration), '--output', str(ROOT / name)]
        if configure:
            cmd += ['--configure']
            if master == 'acorn':
                cmd += ['--master-trim', '35000']
        for role, key in [('master', master), ('slave', slave)]:
            cfg = config[key]
            cmd += ['--' + role + '-uart', cfg['uart'],
                    '--' + role + '-jtag', str(cfg['jtag_port']),
                    '--' + role + '-csr', cfg['csr']]
        with (ROOT / (name + '.log')).open('w') as log:
            subprocess.run(cmd, check=True, stdout=log, stderr=subprocess.STDOUT,
                           timeout=duration + 420)
    finally:
        for board in boards.values():
            board.stop_server()
    if not json.loads((ROOT / name / 'summary.json').read_text())['passed']:
        raise RuntimeError(name + ' did not pass')


def recovery(master):
    name = 'recovery-' + master + '-master'
    update(name)
    cmd = [sys.executable, str(REPO / 'tools/wr_recover.py'),
           '--config', str(ROOT / 'bench.json'), '--master', master,
           '--operation', 'both', '--cycles', '3', '--output', str(ROOT / name)]
    if master == 'acorn':
        cmd += ['--master-trim', '35000']
    with (ROOT / (name + '.log')).open('w') as log:
        subprocess.run(cmd, check=True, stdout=log, stderr=subprocess.STDOUT, timeout=2700)
    if not json.loads((ROOT / name / 'summary.json').read_text())['passed']:
        raise RuntimeError(name + ' did not pass')


def review():
    reviewed = json.loads((ROOT / 'candidate-reviewed.json').read_text())
    if not reviewed['passed']:
        raise RuntimeError('Candidate build review failed')
    manifest = json.loads((ROOT / reviewed['manifest']).read_text())
    for key, cfg in config.items():
        for item in ['bitstream', 'csr']:
            path = Path(cfg[item])
            expected = manifest['images'][key]['files'][str(path.relative_to(ROOT))]['sha256']
            if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                raise RuntimeError(key + ' ' + item + ' hash changed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['warm', 'full'])
    args = parser.parse_args()
    lock = (ROOT / 'bench.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        review()
        if args.stage == 'warm':
            qualify('warm-acorn-master', 'acorn', 120, configure=True, reload=True)
            qualify('warm-spec-master', 'spec', 120, configure=True)
        else:
            for master in ('acorn', 'spec'):
                if not json.loads((ROOT / ('warm-' + master + '-master') / 'summary.json').read_text())['passed']:
                    raise RuntimeError('Warm tests must pass before full qualification')
            recovery('spec')
            qualify('soak-spec-master', 'spec', 1800)
            qualify('soak-acorn-master', 'acorn', 1800, configure=True)
            recovery('acorn')
            qualify('final-acorn-master', 'acorn', 60)
        state['passed'] = True
        update(args.stage + '-completed')
    except BaseException as error:
        state['error'] = str(error)
        update('failed')
        raise


if __name__ == '__main__':
    main()
