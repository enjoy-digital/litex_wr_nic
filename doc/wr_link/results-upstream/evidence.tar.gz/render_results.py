#!/usr/bin/env python3
"""Publish the completed upstream bench matrix and replayable evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'source/doc/wr_link/results-upstream'


def digest(path):
    return {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'bytes': path.stat().st_size}


def main():
    matrix = json.loads((ROOT / 'matrix-summary.json').read_text())
    if not matrix['complete']:
        raise RuntimeError('Complete upstream hardware matrix required')
    inspection = json.loads((ROOT / 'final-inspection/summary.json').read_text())
    if not inspection['passed']:
        raise RuntimeError('Final PLL and clock inspection must pass')
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    OUT.mkdir(parents=True, exist_ok=True)
    for name in ('matrix-summary.json', 'manifest.json', 'source-provenance.json'):
        shutil.copy2(ROOT / name, OUT / name)
    fig, axes = plt.subplots(2, 1, figsize=(10, 6), sharex=True, sharey=True, layout='constrained')
    for ax, name, label, color in zip(axes, ('acorn', 'spec'),
            ('Acorn master → SPEC slave', 'SPEC master → Acorn slave'), ('#2563a6', '#b45b16')):
        rows = [json.loads(line) for line in (ROOT / ('soak-' + name + '-master') / 'samples.jsonl').read_text().splitlines()]
        rows = [r for r in rows if r['soak_elapsed'] is not None]
        ax.plot([r['soak_elapsed'] / 60 for r in rows],
                [r['diagnostics']['slave']['offset_ps'] for r in rows], lw=.7, color=color)
        ax.axhline(120, color='#888', ls='--', lw=.7)
        ax.axhline(-120, color='#888', ls='--', lw=.7)
        ax.set_title(label, loc='left', fontsize=11)
        ax.set_ylabel('Reported offset (ps)')
        ax.grid(alpha=.18)
        ax.set_ylim(-135, 135)
    axes[-1].set_xlabel('Uninterrupted tracking time (minutes)')
    fig.suptitle('Complete upstream rebuild — internal servo estimates', fontsize=12)
    fig.savefig(OUT / 'servo-offsets.svg')
    fig.savefig(OUT / 'servo-offsets.png', dpi=160)
    plt.close(fig)

    files = []
    for name in ('warm-acorn-master', 'warm-spec-master', 'soak-acorn-master',
                 'soak-spec-master', 'recovery-acorn-master', 'recovery-spec-master',
                 'final-acorn-master', 'final-inspection', 'failed-console-overflow'):
        files += [p for p in (ROOT / name).rglob('*') if p.is_file()]
    for pattern in ('warm-*-boot*', 'tests-*.log', 'build-*.log'):
        files += [p for p in ROOT.glob(pattern) if p.is_file()]
    for name in ('manifest.json', 'source-provenance.json', 'candidate-reviewed.json',
                 'matrix-summary.json', 'tests-summary.json', 'qualify_upstream.py', 'review_builds.py', 'inspect_final.py',
                 'bench.json', 'bench-local.json', 'run_pair.py', 'jtag_servers.py',
                 'summarize_qualification.py', 'render_results.py', 'verify_ptm_equivalence.py', 'ptm-equivalence.json'):
        files.append(ROOT / name)
    for name in ('acorn-console', 'spec-console'):
        files += [p for p in (ROOT / name).iterdir() if p.is_file() and p.suffix in
                  ('.patch', '.csv', '.config', '.bin', '.bram', '.boot', '.elf')]
        files.append(ROOT / name / 'input-files.json')
    for name, top in [('acorn-console', 'sqrl_acorn'), ('spec-console', 'spec_a7_wr_nic'),
                      ('spec', 'spec_a7_wr_nic')]:
        files.append(ROOT / name / 'gateware' / (top + '_timing.rpt'))
    files = sorted(set(files))
    archive = OUT / 'evidence.tar.gz'
    with archive.open('wb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
        for path in files:
            info = tar.gettarinfo(str(path), arcname=str(path.relative_to(ROOT)))
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ''
            with path.open('rb') as data:
                tar.addfile(info, data)
    (OUT / 'evidence-files.json').write_text(json.dumps({str(p.relative_to(ROOT)): digest(p) for p in files}, indent=2) + '\n')

    lines = ['# Complete upstream hardware qualification', '',
        'Both FPGA images were rebuilt from official WR-core `8cc5e532` and WRPC `13527cd6`, with firmware PPSI `33d8c46c`. The [source and build notes](../upstream-build.md) describe the integration patches and SPEC timing adjustment. These results are separate from the [older pinned-source qualification](../results/README.md).', '',
        'The bench uses uRV with private 128 KiB RAM, USB UART/JTAG, and Acorn SFP0 connected to SPEC-A7 J12/SFP0. Programming was to SRAM; firmware flash writes and erases were disabled.', '',
        'These images include the 256-byte UART print buffer correction. The first upstream hardware run exposed an overflow in the previous 16-byte project setting and was rejected; its raw evidence is preserved under `failed-console-overflow/` in the archive. The compiled buffer size was checked before loading, and the passing runs contained no overflow warning.', '',
        '| Master → slave | Continuous tracking | Samples | Internal offset range | Standard deviation |',
        '| --- | ---: | ---: | ---: | ---: |']
    for name, label in [('acorn', 'Acorn → SPEC'), ('spec', 'SPEC → Acorn')]:
        s = matrix['soaks'][name]; o = s['offset_ps']
        lines.append(f"| {label} | {s['soak_s']:.1f} s | {s['samples']} | {o['minimum']}…{o['maximum']} ps | {o['standard_deviation']:.2f} ps |")
    lines += ['', 'Each run retained WR `IDLE / EXT_ON`, the intended roles, PLL/frequency lock, and slave `TRACK_PHASE`. Time and servo updates advanced, RX error counters stayed unchanged, and raw UART replay passed.', '',
        '![Internal servo offsets](servo-offsets.svg)', '',
        'These are internal servo estimates. SFP delay/asymmetry calibration and independent PPS accuracy measurements remain separate work. The free-running master time is not traceable UTC/TAI.', '',
        '| Master | Interruption | Recovery upper bounds, cycles 1 / 2 / 3 |',
        '| --- | --- | ---: |']
    for name, label in [('acorn', 'Acorn'), ('spec', 'SPEC')]:
        for op, title in [('link', 'PCS disable/enable'), ('reload', 'Both boards SRAM reloaded')]:
            rows = [r for r in matrix['recoveries'][name]['cycles'] if r['operation'] == op]
            lines.append(f'| {label} | {title} | ' + ' / '.join(f"{r['recovery_upper_bound_s']:.1f} s" for r in rows) + ' |')
    lines += ['', 'Each PCS interruption lasted at least five seconds, with link-down observed on both boards and a UART response from each. This resets the PCS through brief uRV debug transactions; it is not physical cable removal. Every reload matched the reviewed image hash and every recovery passed the same WR checks.', '',
        'Final state: Acorn master with volatile main trim 35000, SPEC slave. Both physical UARTs are released after observation.', '',
        'The final inspection also captures UART `pll stat`, main/helper tuning commands, and raw clock/MMCM CSRs. Acorn MMCM completion-fault flags were clear. The clock-counter estimates are host observations and are not independent oscillator-accuracy measurements.', '',
        '| Board | Setup WNS | Hold WHS |', '| --- | ---: | ---: |']
    for name in ('acorn', 'spec'):
        item = manifest['images'][name]
        lines.append(f"| {name} | {item['wns_ns']:+.3f} ns | {item['whs_ns']:+.3f} ns |")
    lines += ['', 'Focused validation: 81 WR tests and the LitePCIe packet regression passed. A separate 12,000-cycle comparison matched the original PTM formatter cycle by cycle. The two XSim tests required execution outside the process sandbox after its simulator launcher failed inside it. Build reports and test logs are included in the evidence.', '',
        f"[Evidence archive](evidence.tar.gz): {digest(archive)['bytes']:,} bytes; SHA-256 `{digest(archive)['sha256']}`. [File hashes](evidence-files.json) and [image manifest](manifest.json) identify the exact inputs and outputs. FPGA bitstreams remain in the local build directory.", '',
        '## Replay without hardware', '', 'From the repository root:', '', '```sh',
        'mkdir -p /tmp/wr-upstream-evidence',
        'tar -xzf doc/wr_link/results-upstream/evidence.tar.gz -C /tmp/wr-upstream-evidence',
        'python3 /tmp/wr-upstream-evidence/summarize_qualification.py --repository "$PWD"',
        '```', '', 'The output must contain `"complete": true`.', '']
    (OUT / 'README.md').write_text('\n'.join(lines))
    print(OUT)


if __name__ == '__main__':
    main()
