import json,time
from pathlib import Path
r=Path(__file__).resolve().parent
s=json.loads((r/'pipeline-state.json').read_text())
x={'time':time.strftime('%H:%M:%S'),'stage':s['stage']}
if s.get('error'):x['error']=s['error']
p=r/s['stage']
if (p/'summary.json').exists():
 d=json.loads((p/'summary.json').read_text());x['passed']=d.get('passed');x['cycles']=len(d.get('results',[]))
for f in sorted(p.rglob('samples.jsonl'),key=lambda f:f.stat().st_mtime,reverse=True) if p.exists() else []:
 if not f.stat().st_size:continue
 with f.open('rb') as b:
  b.seek(max(0,f.stat().st_size-32768));lines=b.read().splitlines()
 for line in reversed(lines):
  try:d=json.loads(line)
  except json.JSONDecodeError:continue
  x.update(sample=str(f.relative_to(p)),soak_s=round(d['soak_elapsed'] or 0),errors=d['errors'],age_s=round(time.time()-f.stat().st_mtime));break
 if 'sample' in x:break
print(json.dumps(x))
