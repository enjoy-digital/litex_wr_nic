#!/usr/bin/env python3
"""Render a completed gain qualification with raw, replayable evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'source/doc/wr_link/results-gain'


def digest(path):
    return {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}


def commands(path, board='spec'):
    record = json.loads(path.read_text())
    if 'boards' in record:
        return record['boards'][board]['commands']
    return {c['command']: c['response'] for c in record['commands']}


def dac_code(cmds, channel):
    key = 'pll gdac '+str(channel)
    return int(re.search(r'\n(\d+)\n', cmds[key])[1])


def main():
    matrix = json.loads((ROOT/'matrix-summary.json').read_text())
    assert matrix['complete']
    assert json.loads((ROOT/'final-inspection/summary.json').read_text())['passed']
    manifest = json.loads((ROOT/'manifest.json').read_text())
    assert manifest['images']['spec']['dac_gain'] == {'refclk': 2, 'dmtd': 1}
    OUT.mkdir(parents=True, exist_ok=True)
    for name in ['matrix-summary.json', 'manifest.json', 'source-provenance.json']:
        shutil.copy2(ROOT/name, OUT/name)
    fig, axes = plt.subplots(2, 1, figsize=(10, 6), sharex=True, sharey=True, layout='constrained')
    for ax, master, label in zip(axes, ['acorn', 'spec'], ['Acorn → SPEC', 'SPEC → Acorn']):
        rows = [json.loads(s) for s in (ROOT/('soak-'+master+'-master')/'samples.jsonl').read_text().splitlines()]
        rows = [s for s in rows if s['soak_elapsed'] is not None]
        ax.plot([s['soak_elapsed']/60 for s in rows],
                [s['diagnostics']['slave']['offset_ps'] for s in rows], linewidth=.7)
        ax.set_title(label, loc='left')
        ax.set_ylabel('Reported offset (ps)')
        ax.set_ylim(-135, 135)
        ax.axhline(120, color='#888', linestyle='--', linewidth=.6)
        ax.axhline(-120, color='#888', linestyle='--', linewidth=.6)
        ax.grid(alpha=.2)
    axes[-1].set_xlabel('Uninterrupted tracking time (minutes)')
    fig.suptitle('SPEC DMTD ×1 gain — internal servo estimates')
    fig.savefig(OUT/'servo-offsets.svg')
    plt.close(fig)

    files = set()
    for path in ROOT.iterdir():
        if path.is_file() and path.suffix in ['.json', '.py', '.log', '.patch']:
            files.add(path)
        elif path.is_dir() and path.name.startswith(('warm-', 'soak-', 'recovery-', 'final-', 'baseline-', 'failed-', 'interrupted-')):
            files.update(p for p in path.rglob('*') if p.is_file())
    for name, top in [('spec-gain', 'spec_a7_wr_nic'), ('acorn-console', 'sqrl_acorn')]:
        files.update(p for p in (ROOT/name).iterdir() if p.is_file())
        files.add(ROOT/name/'gateware'/(top+'_timing.rpt'))
    files.add(ROOT/'spec-gain/gateware/spec_a7_wr_nic.v')
    archive = OUT/'evidence.tar.gz'
    with archive.open('wb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
        for path in sorted(files):
            info = tar.gettarinfo(str(path), arcname=str(path.relative_to(ROOT)))
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ''
            with path.open('rb') as data:
                tar.addfile(info, data)
    (OUT/'evidence-files.json').write_text(json.dumps({str(p.relative_to(ROOT)): digest(p) for p in sorted(files)}, indent=2)+'\n')

    notes = (ROOT/'gain-notes-draft.md').read_text().replace('Hardware results pending. Only passing measured results will be published as qualification.\n', '')
    lines = [notes, '## Hardware results', '',
        'Both directions passed 30 uninterrupted minutes, three PCS interruptions and three paired SRAM reloads. Each run checked the intended roles, WR `IDLE / EXT_ON`, PLL/frequency lock, slave `TRACK_PHASE`, advancing time/updates and unchanged RX error counters. Raw UART replay passed.', '',
        '| Master → slave | Tracking | Internal offset range | Standard deviation |',
        '| --- | ---: | ---: | ---: |']
    for master, label in [('acorn', 'Acorn → SPEC'), ('spec', 'SPEC → Acorn')]:
        s = matrix['soaks'][master]; o = s['offset_ps']
        lines.append(f"| {label} | {s['soak_s']:.1f} s | {o['minimum']}…{o['maximum']} ps | {o['standard_deviation']:.2f} ps |")
    lines += ['', '![Internal servo offsets](servo-offsets.svg)', '',
        'These are internal servo estimates, not independent PPS accuracy measurements. The [original ×2 qualification](../results-upstream/README.md) remains available for comparison. The two runs do not establish a gain-dependent accuracy improvement.', '',
        '| Master | Interruption | Recovery upper bounds, cycles 1 / 2 / 3 |',
        '| --- | --- | ---: |']
    for master in ['acorn', 'spec']:
        for op, label in [('link', 'PCS disable/enable'), ('reload', 'Both SRAM images reloaded')]:
            rows = [r for r in matrix['recoveries'][master]['cycles'] if r['operation'] == op]
            lines.append(f'| {master.capitalize()} | {label} | '+' / '.join(f"{r['recovery_upper_bound_s']:.1f} s" for r in rows)+' |')
    lines += ['', 'PCS interruption held the link down on both boards for at least five seconds; both UARTs remained responsive. It tests PCS reset/recovery rather than physical connector removal.', '',
        '## DAC operating points', '',
        'UART readings taken before the change and after each candidate soak follow. These are controller command codes, not measured voltages; temperature and servo activity also affect them.', '',
        '| SPEC role | Old ×2 DMTD code | New ×1 DMTD code | New main code (×2) |',
        '| --- | ---: | ---: | ---: |']
    for master, role in [('acorn', 'Slave'), ('spec', 'Master')]:
        old = commands(ROOT/('baseline-'+master+'-master')/'summary.json')
        new = commands(ROOT/('soak-'+master+'-master-pll')/'spec.json')
        lines.append(f'| {role} | {dac_code(old,-1)} | {dac_code(new,-1)} | {dac_code(new,0)} |')
    spec = manifest['images']['spec']
    lines += ['', 'The generic driver defaults to ×2 to preserve the previous effective behavior for other callers. SPEC explicitly selects ×1 for DMTD. RefClk remains ×2. Qualification applies to this connected bench and its tested master settings; it does not characterize all oscillator tolerances or temperature extremes.', '',
        '## Reproduction and evidence', '',
        'Use the [USB bench guide](../../wr_link_qualification.md) and the same upstream sources/dependency corrections as the baseline. Build SPEC with:', '', '```sh',
        'python3 spec_a7_wr_nic.py --build --wr-cpu-type urv --wr-cpu-memory private --wr-read-only-storage', '```', '',
        f"SPEC final setup/hold slack: {spec['wns_ns']:+.3f}/{spec['whs_ns']:+.3f} ns. Acorn is the unchanged, previously qualified image. Three DAC simulations pass, decoding the actual SPI initialization and queued update words for default/×1/×2. The same tests reject the original driver. Vivado confirms both boolean generic bindings; the firmware retains its compiled 256-byte print buffer.", '',
        'Final bench state: Acorn master (volatile trim 35000), SPEC slave with DMTD ×1. Programming used SRAM only and the firmware disabled flash writes/erases.', '',
        f"[Raw evidence](evidence.tar.gz): {digest(archive)['bytes']:,} bytes, SHA-256 `{digest(archive)['sha256']}`. [File hashes](evidence-files.json) and the [image manifest](manifest.json) identify exact artifacts. FPGA bitstreams remain local.", '',
        'Replay without hardware from the repository root:', '', '```sh',
        'mkdir -p /tmp/wr-gain-evidence',
        'tar -xzf doc/wr_link/results-gain/evidence.tar.gz -C /tmp/wr-gain-evidence',
        'python3 /tmp/wr-gain-evidence/summarize_qualification.py --repository "$PWD"',
        '```', '', 'The result must contain `"complete": true`.', '']
    (OUT/'README.md').write_text('\n'.join(lines))
    print(OUT)


if __name__ == '__main__':
    main()
