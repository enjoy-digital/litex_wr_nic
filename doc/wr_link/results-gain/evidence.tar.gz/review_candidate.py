#!/usr/bin/env python3
"""Check timing, firmware provenance and the two emitted DAC gain bindings."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent/'wr_upstream_20260911'


def main():
    build = json.loads((ROOT/'build-state.json').read_text())
    assert build.get('returncode') == 0, 'Candidate build must finish successfully'
    source = ROOT/'source'
    netlist = (ROOT/'spec-gain/gateware/spec_a7_wr_nic.v').read_text()
    instances = re.findall(r'serial_dac_arb #\((.*?)\) serial_dac_arb\w* \((.*?)\);', netlist, re.S)
    assert len(instances) == 2
    gains = {}
    for params, ports in instances:
        name = 'refclk' if 'dac_refclk' in ports else 'dmtd' if 'dac_dmtd' in ports else None
        assert name is not None and name not in gains, ports
        gain = re.search(r"\.g_enable_x2_gain\s+\(1'd([01])\)", params)
        assert gain, params
        gains[name] = 1 + int(gain[1])
    assert gains == {'refclk': 2, 'dmtd': 1}
    assert 'g_x2_gain' not in netlist
    synthesis = (ROOT/'build-spec-gain.log').read_text()
    for value in [0, 1]:
        assert f'Parameter g_enable_x2_gain bound to: {value} - type: bool' in synthesis
    assert "Generic 'g_x2_gain' not present" not in synthesis
    # The entire firmware overlay must match the already-qualified SPEC profile.
    for rel in ['litex_wr_nic/firmware/build.py', 'litex_wr_nic/firmware/spec_a7_defconfig']:
        assert (source/rel).read_bytes() == (BASE/'source'/rel).read_bytes(), rel
    for rel in ['wr-cores', 'litex_wr_nic/firmware/wrpc-sw']:
        def revision(path):
            return subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True)
        assert revision(source/rel) == revision(BASE/'source'/rel)
    subprocess.run(['python3', str(ROOT/'review_builds.py')], check=True)
    manifest = json.loads((ROOT/'manifest.json').read_text())
    baseline = json.loads((BASE/'manifest.json').read_text())
    assert manifest['images']['acorn']['files'] == baseline['images']['acorn']['files']
    files = subprocess.check_output(['git', '-C', str(source), 'ls-files', '-z']).split(b'\0')
    inputs = {path.decode(): hashlib.sha256((source/path.decode()).read_bytes()).hexdigest()
              for path in files if path and (source/path.decode()).is_file()}
    (ROOT/'spec-gain/input-files.json').write_text(json.dumps(inputs, indent=2)+'\n')
    manifest['images']['spec']['dac_gain'] = gains
    manifest['images']['acorn']['reused_from'] = str(BASE/'manifest.json')
    (ROOT/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    (ROOT/'candidate-reviewed.json').write_text(json.dumps({
        'passed': True, 'manifest': 'manifest.json', 'spec_dac_gain': gains,
        'firmware_profile_unchanged': True, 'acorn_image_unchanged': True,
        'integration_commit': subprocess.check_output(['git', '-C', str(source),
            'rev-parse', 'HEAD'], text=True).strip()}, indent=2)+'\n')
    print('Reviewed candidate: SPEC RefClk x2 / DMTD x1; Acorn image unchanged.')


if __name__ == '__main__':
    main()
