#!/usr/bin/env python3
"""Audit the actual captures, retaining the user's shortened qualification scope."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repository', type=Path, required=True)
parser.add_argument('--evidence', type=Path, default=Path(__file__).resolve().parent)
args = parser.parse_args()
ROOT = args.evidence
spec = importlib.util.spec_from_file_location('wr_status', args.repository/'tools/wr_status.py')
status = importlib.util.module_from_spec(spec)
spec.loader.exec_module(status)
manifest = json.loads((ROOT/'manifest.json').read_text())
assert json.loads((ROOT/'qualification-limit.json').read_text())['reason'].startswith('User:')
assert manifest['images']['spec']['dac_gain'] == {'refclk': 2, 'dmtd': 1}
for board in ['spec', 'acorn']:
    item = manifest['images'][board]
    assert item['wr_core_commit'] == '8cc5e53275d229fbbf50b96a6ae4cb9c87626d53'
    assert item['wrpc_commit'] == '13527cd68e1833214a89e4ee8c5b208188ff0e6a'
    assert item['compiled_print_buffer_bytes'] == 256


def audit_run(name, required=None):
    path = ROOT/name
    rows = []
    lines = (path/'samples.jsonl').read_bytes().splitlines()
    trailing_partial_line = False
    for i, line in enumerate(lines):
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            assert i == len(lines)-1, 'Malformed non-final sample'
            trailing_partial_line = True
    rows = [r for r in rows if r['soak_elapsed'] is not None]
    assert len(rows) >= 2
    if required is not None:
        summary = json.loads((path/'summary.json').read_text())
        assert summary['passed'] and summary['soak_seconds'] >= required
    previous = None
    for row in rows:
        assert not row['errors']
        g, d = row['gui'], row['diagnostics']
        assert not status.qualification_errors(g['master'], g['slave'], d['master'], d['slave'],
            max(f['received'] for f in g.values()))
        for role in ['master', 'slave']:
            assert d[role]['raw'][10] < 1_000_000_000
            if previous:
                assert d[role]['tai_ns'] >= previous['diagnostics'][role]['tai_ns']
                assert d[role]['rx_errors'] == previous['diagnostics'][role]['rx_errors']
        if previous:
            assert 0 <= row['soak_elapsed']-previous['soak_elapsed'] < 5, 'Observation gap'
            assert (d['slave']['updates']-previous['diagnostics']['slave']['updates']) & 0xffffffff < 0x80000000
        previous = row
    offsets = [r['diagnostics']['slave']['offset_ps'] for r in rows]
    result = {'audit_passed': True, 'samples': len(rows),
        'observed_tracking_seconds': rows[-1]['soak_elapsed']-rows[0]['soak_elapsed'],
        'completed_check_seconds': summary['soak_seconds'] if required is not None else None,
        'trailing_partial_sample': trailing_partial_line,
        'offset_ps': {'minimum': min(offsets), 'maximum': max(offsets),
            'mean': statistics.mean(offsets), 'standard_deviation': statistics.pstdev(offsets)},
        'termination': 'completed' if required is not None else
            'user-requested stop' if name == 'soak-spec-master' else 'foreground session interrupted',
        'raw_uart': {}}
    for role in ['master', 'slave']:
        raw = (path/(role+'.uart.raw')).read_bytes()
        assert b'PRINTF OVF' not in raw
        frames = status.WRScreen().feed(raw, now=0)
        def good(f):
            return (f['role'] == role.upper() and f['extension'] == 'IDLE' and
                f['detection'] == 'EXT_ON' and f['pll_locked'] and f['frequency_locked'] and
                (role == 'master' or f['servo'] == 'TRACK_PHASE'))
        first = next(i for i, f in enumerate(frames) if good(f))
        assert all(good(f) for f in frames[first:]), name+': lost tracking in raw UART'
        result['raw_uart'][role] = {'frames': len(frames), 'first_tracking_frame': first,
            'nontracking_frames_after_first': 0, 'sha256': hashlib.sha256(raw).hexdigest()}
    return result


result = {'audited': False, 'scope': 'Stopped at user request; planned full matrix was not completed',
    'full_matrix_completed': False, 'runs': {}, 'recovery_master': 'spec'}
for name, minimum in [('warm-acorn-master', 120), ('warm-spec-master', 120),
                      ('interrupted-soak-spec-master', None), ('soak-spec-master', None)]:
    result['runs'][name] = audit_run(name, minimum)
recovery = json.loads((ROOT/'recovery-spec-master/summary.json').read_text())
assert recovery['passed']
rows = recovery['results']
for op in ['link', 'reload']:
    assert sorted(r['cycle'] for r in rows if r['operation'] == op) == [1, 2, 3]
result['recoveries'] = []
for cycle in rows:
    assert cycle['qualification']['passed']
    assert cycle['recovery_upper_bound_seconds'] <= 300
    if cycle['operation'] == 'reload':
        assert sorted(b['board'] for b in cycle['reloads']) == ['acorn', 'spec']
        for b in cycle['reloads']:
            expected = {v['sha256'] for p,v in manifest['images'][b['board']]['files'].items()
                        if '/gateware/' in p and p.endswith(('.bit', '.bin'))}
            assert b['passed'] and b['sha256'] in expected and '13527cd6' in b['version']
    else:
        d = cycle['interruption']
        assert d['passed'] and d['enabled_unix']-d['disabled_unix'] >= 5
        assert any(len(s) == 2 and all(not v['link'] for v in s.values()) for s in d['samples'])
        assert all('WR Core build:' in d[b+'_during_down_version'] for b in ['acorn','spec'])
    capture = 'recovery-spec-master/'+cycle['operation']+'-'+str(cycle['cycle'])+'/reacquired'
    audit_run(capture, 10)
    result['recoveries'].append({'operation': cycle['operation'], 'cycle': cycle['cycle'],
        'recovery_upper_bound_s': cycle['recovery_upper_bound_seconds']})
result['audited'] = True
(ROOT/'gain-summary.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
