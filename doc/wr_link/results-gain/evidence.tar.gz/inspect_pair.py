#!/usr/bin/env python3
"""Record PLL commands and clock status without changing the configured PTP roles."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
os.environ['PYTHONPATH'] = str(ROOT/'litex')
sys.path[:0] = [str(ROOT/'litex'), str(ROOT/'source/tools')]
from wr_recover import Board


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('label')
    parser.add_argument('--baseline', action='store_true')
    args = parser.parse_args()
    assert '/' not in args.label and '..' not in args.label
    lock = (ROOT/'bench.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    out = ROOT/args.label
    out.mkdir(exist_ok=False)
    cfgroot = ROOT.parent/'wr_upstream_20260911' if args.baseline else ROOT
    config = json.loads((cfgroot/'bench.json').read_text())
    boards = {name: Board(name, cfg) for name, cfg in config.items()}
    summary = {'passed': False, 'baseline': args.baseline, 'boards': {}}
    try:
        for name, board in boards.items():
            cfg = config[name]
            with socket.socket() as probe:
                running = probe.connect_ex(('127.0.0.1', cfg['jtag_port'])) == 0
            if not running:
                board.start_server(out/(name+'-jtag.log'))
            with (out/(name+'-status.log')).open('w') as log:
                subprocess.run([sys.executable, str(ROOT/'source/tools/wr_link.py'),
                    'status', '--port', str(cfg['jtag_port']), '--csr-csv', cfg['csr'],
                    '--output', str(out/(name+'-status.json'))],
                    check=True, stdout=log, stderr=subprocess.STDOUT, timeout=60)
            command = [sys.executable, str(ROOT/'source/tools/wr_link.py'), 'console',
                '--port', cfg['uart'], '--output', str(out/(name+'-console')),
                '--monitor-seconds', '12']
            for cmd in ['ver', 'ptp', 'pll stat', 'pll gdac 0', 'pll gdac -1']:
                command += ['--command', cmd]
            with (out/(name+'-console.log')).open('w') as log:
                subprocess.run(command, check=True, stdout=log,
                    stderr=subprocess.STDOUT, timeout=120)
            uart = json.loads((out/(name+'-console.json')).read_text())
            assert uart['passed']
            assert 'PRINTF OVF' not in (out/(name+'-console.uart.raw')).read_text()
            summary['boards'][name] = {
                'commands': {c['command']: c['response'] for c in uart['commands']}}
        summary['passed'] = True
    except BaseException as error:
        summary['error'] = str(error)
        raise
    finally:
        for board in boards.values():
            board.stop_server()
        (out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
