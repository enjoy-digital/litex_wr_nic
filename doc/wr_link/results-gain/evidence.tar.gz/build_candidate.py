#!/usr/bin/env python3
"""Build only the SPEC gain candidate, preserving the qualified upstream baseline."""
import json, os, subprocess, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'wr_upstream_20260911'
env = os.environ.copy()
env['PYTHONPATH'] = str(BASE / 'litepcie')
command = ['python3', 'spec_a7_wr_nic.py', '--build', '--wr-cpu-type', 'urv',
           '--wr-cpu-memory', 'private', '--wr-read-only-storage',
           '--output-dir', str(ROOT / 'spec-gain')]
state = dict(command=command, started_unix=time.time(), environment={'PYTHONPATH': env['PYTHONPATH']})
(ROOT / 'build-state.json').write_text(json.dumps(state, indent=2)+'\n')
with (ROOT / 'build-spec-gain.log').open('w') as log:
    result = subprocess.run(command, cwd=ROOT/'source', env=env, stdout=log, stderr=subprocess.STDOUT)
state.update(finished_unix=time.time(), returncode=result.returncode)
(ROOT / 'build-state.json').write_text(json.dumps(state, indent=2)+'\n')
print(state)
raise SystemExit(result.returncode)
