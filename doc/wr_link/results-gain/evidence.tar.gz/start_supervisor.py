#!/usr/bin/env python3
"""Start the reviewed bench test in its own session and retain its identity."""
import fcntl
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
assert json.loads((ROOT/'candidate-reviewed.json').read_text())['passed']
assert json.loads((ROOT/'recovery-spec-master/summary.json').read_text())['passed']
assert not (ROOT/'supervisor.json').exists()
with (ROOT/'bench.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
with (ROOT/'supervisor.log').open('w') as log:
    process = subprocess.Popen(['python3', str(ROOT/'finish_qualification.py')],
        stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
        start_new_session=True)
record = {'pid': process.pid, 'started_unix': time.time(),
    'start_ticks': (Path('/proc')/str(process.pid)/'stat').read_text().split()[21]}
(ROOT/'supervisor.json').write_text(json.dumps(record, indent=2)+'\n')
print(record)
