#!/usr/bin/env python3
"""Configure and verify this USB WR bench using its qualified images and tools."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / 'litex'), str(ROOT / 'source/tools')]
from wr_recover import Board


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('master', choices=['acorn', 'spec'])
    parser.add_argument('--observe', action='store_true', help='Check existing roles without restarting PTP.')
    parser.add_argument('--duration', type=float, default=120, help='Required uninterrupted tracking, in seconds (default: 120).')
    parser.add_argument('--reload', action='store_true', help='Load both qualified images into SRAM first; existing JTAG servers must be stopped.')
    args = parser.parse_args()
    if args.duration <= 0:
        parser.error('--duration must be positive')
    if args.reload and args.observe:
        parser.error('--reload requires configuring roles; omit --observe')
    lock = (ROOT / 'bench.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    config = json.loads((ROOT / 'bench-local.json').read_text())
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    boards = {name: Board(name, cfg) for name, cfg in config.items()}
    existing = {}
    # Complete all image and board-identity checks before any programming or role changes.
    for name, cfg in config.items():
        usb = Path('/sys/bus/usb/devices') / cfg['usb_location']
        assert [(usb / key).read_text().strip() for key in ('idVendor', 'idProduct')] == ['0403', '6011'], name + ': unexpected USB device'
        uart = Path('/sys/class/tty') / Path(cfg['uart']).resolve().name / 'device'
        assert cfg['usb_location'] in [p.name for p in uart.resolve().parents], name + ': UART/JTAG USB mapping differs'
        for key in ('bitstream', 'csr'):
            path = Path(cfg[key])
            expected = manifest['images'][name]['files'][str(path.relative_to(ROOT))]['sha256']
            assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name + ': qualified ' + key + ' changed'
        with socket.socket() as probe:
            existing[name] = probe.connect_ex(('127.0.0.1', cfg['jtag_port'])) == 0
        if args.reload and existing[name]:
            raise RuntimeError(name + ': stop the JTAG server before --reload (see RUNNING.md)')
    runs = ROOT / 'runs'
    runs.mkdir(exist_ok=True)
    output = Path(tempfile.mkdtemp(prefix=time.strftime('%Y%m%d-%H%M%S-') + args.master + '-', dir=runs))
    env = os.environ.copy()
    env['PYTHONPATH'] = str(ROOT / 'litex') + os.pathsep + env.get('PYTHONPATH', '')
    # Board.start_server inherits the same pinned LiteX path as the qualifier.
    os.environ['PYTHONPATH'] = env['PYTHONPATH']
    print('Evidence:', output, flush=True)
    try:
        for name, board in boards.items():
            if args.reload:
                board.reload(output / (name + '-boot'))
            elif not existing[name]:
                board.start_server(output / (name + '-jtag.log'))
            bus = board.client()
            try:
                identifier = bytes(v & 255 for v in bus.read(bus.bases.identifier_mem, length=128)).split(b'\0')[0].decode()
                expected = 'Acorn Baseboard Mini' if name == 'acorn' else 'SPEC-A7'
                assert expected in identifier, name + ': wrong FPGA at JTAG port: ' + identifier
                print(name + ': ' + identifier, flush=True)
            finally:
                bus.close()
        slave = 'spec' if args.master == 'acorn' else 'acorn'
        command = [sys.executable, str(ROOT / 'source/tools/wr_qualify.py'),
                   '--duration', str(args.duration), '--acquire-timeout', '300',
                   '--output', str(output / 'qualification')]
        for role, name in [('master', args.master), ('slave', slave)]:
            cfg = config[name]
            command += ['--' + role + '-uart', cfg['uart'], '--' + role + '-jtag', str(cfg['jtag_port']),
                        '--' + role + '-csr', cfg['csr']]
        if not args.observe:
            command += ['--configure']
            if args.master == 'acorn':
                command += ['--master-trim', '35000']
        env['PYTHONUNBUFFERED'] = '1'
        process = subprocess.Popen(command, env=env, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True)
        try:
            with (output / 'qualification.log').open('w') as log:
                for line in process.stdout:
                    log.write(line)
                    if line.startswith('WR tracking acquired') or line.startswith('{"elapsed":'):
                        print(line.rstrip(), flush=True)
            if process.wait() != 0:
                print((output / 'qualification.log').read_text()[-3000:], file=sys.stderr)
                raise RuntimeError('WR qualification failed; see ' + str(output))
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
        result = json.loads((output / 'qualification/summary.json').read_text())
        assert result['passed'], 'WR qualification did not pass'
        (ROOT / 'latest-run.json').write_text(json.dumps({'master': args.master, 'output': str(output), 'passed': True}, indent=2) + '\n')
        print('PASS: ' + args.master + ' master -> ' + slave + ' slave; UARTs released.', flush=True)
    finally:
        for board in boards.values():
            board.stop_server()
        lock.close()


if __name__ == '__main__':
    main()
