#!/usr/bin/env python3
"""Finish releasing the verified debug groups after the user's stop request."""
import fcntl
import os
from pathlib import Path
import signal
import time

ROOT = Path(__file__).resolve().parent
with (ROOT/'bench.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for name, pid, group in [('acorn', 31630, 31627), ('spec', 31639, 31639)]:
        process = Path('/proc')/str(pid)
        argv = process.joinpath('cmdline').read_bytes().decode().split('\0')
        assert str(ROOT.parent/'wr_link_20260911'/(name+'-usb.cfg')) in argv
        assert process.joinpath('fd/1').resolve() == ROOT/('soak-spec-master-'+name+'-jtag.log')
        assert os.getpgid(pid) == group
        os.killpg(group, signal.SIGTERM)
        time.sleep(.5)
        try:
            os.killpg(group, signal.SIGKILL)
        except ProcessLookupError:
            pass
print('Stopped the remaining owned debug process groups; FPGA images unchanged.')
