#!/usr/bin/env python3
"""Archive the completed build outputs and require nonnegative final timing."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()


def main():
    manifest = {
        'description': 'SPEC DMTD x1 gain rebuild of the qualified upstream sources; Acorn image reused unchanged',
        'cpu': 'urv', 'memory': 'private 128 KiB',
        'persistent_storage': 'read-only firmware; SRAM programming only',
        'source_provenance': json.loads((ROOT / 'source-provenance.json').read_text()),
        'images': {},
    }
    for board, checkout, top in [('spec', 'source', 'spec_a7_wr_nic'),
                                 ('acorn', 'acorn-source', 'sqrl_acorn')]:
        source = ROOT / checkout
        output = Path(json.loads((ROOT / 'bench.json').read_text())[board]['csr']).parent
        log = (ROOT / ('build-' + output.name + '.log')).read_text()
        if 'Bitgen Completed Successfully' not in log:
            raise RuntimeError(board + ': build has not completed bitstream generation')
        report = output / 'gateware' / (top + '_timing.rpt')
        timing = report.read_text()
        match = re.search(r'WNS\(ns\).*?\n\s*-+.*?\n\s*([-\d.]+)\s+([-\d.]+)\s+(\d+)\s+(\d+)\s+([-\d.]+)\s+([-\d.]+)\s+(\d+)\s+(\d+)\s+([-\d.]+)', timing, re.S)
        if not match:
            raise RuntimeError(board + ': timing summary not found')
        wns, whs, wpws = map(float, (match[1], match[5], match[9]))
        if min(wns, whs, wpws) < 0 or int(match[3]) or int(match[7]):
            raise RuntimeError(board + ': negative final timing slack ' + str((wns, whs, wpws)))
        if 'All user specified timing constraints are met.' not in timing:
            raise RuntimeError(board + ': timing constraints are not met')
        shutil.copy2(source / 'test/csr.csv', output / 'csr.csv')
        for path in (source / 'litex_wr_nic/firmware').glob('spec_a7_wrc.*'):
            shutil.copy2(path, output / path.name)
        shutil.copy2(source / 'litex_wr_nic/firmware/wrpc-sw/.config', output / 'wrpc.config')
        shutil.copy2(source / 'litex_wr_nic/firmware/wrpc-sw/wrc.elf', output / 'wrc.elf')
        symbols = subprocess.check_output([
            str(ROOT / 'riscv-11.2-small/bin/riscv32-elf-nm'), '-S',
            str(output / 'wrc.elf')], text=True)
        print_buffer = re.search(r'^\S+\s+([0-9a-fA-F]+)\s+\w\s+print_buf$', symbols, re.M)
        if not print_buffer or int(print_buffer[1], 16) != 256:
            raise RuntimeError(board + ': compiled UART print buffer must be 256 bytes')
        if board == 'spec':
            subprocess.run(['python3', str(source / 'litex_wr_nic/gateware/xilinx-bitstream.py'),
                            str(output / 'gateware' / (top + '.bit')),
                            str(output / 'gateware' / (top + '.bin'))], check=True)
        item = {'wns_ns': wns, 'whs_ns': whs, 'wpws_ns': wpws,
                'compiled_print_buffer_bytes': 256,
                'integration_commit_at_manifest': git(source, 'rev-parse', 'HEAD'),
                'wr_core_commit': git(source / 'wr-cores', 'rev-parse', 'HEAD'),
                'wrpc_commit': git(source / 'litex_wr_nic/firmware/wrpc-sw', 'rev-parse', 'HEAD'),
                'ppsi_commit': git(source / 'litex_wr_nic/firmware/wrpc-sw/ppsi', 'rev-parse', 'HEAD'),
                'files': {}}
        files = [report, output / 'csr.csv', output / 'wrpc.config', output / 'wrc.elf',
                 output / 'gateware' / (top + '.bit')]
        if board == 'spec':
            files += [output / 'gateware' / (top + '.bin')]
        files += list(output.glob('spec_a7_wrc.*'))
        for path in files:
            data = path.read_bytes()
            item['files'][str(path.relative_to(ROOT))] = {
                'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
        for name, path in [('wr-cores', source / 'wr-cores'),
                           ('general-cores', source / 'wr-cores/ip_cores/general-cores'),
                           ('wrpc-sw', source / 'litex_wr_nic/firmware/wrpc-sw')]:
            (output / (name + '-integration.patch')).write_text(git(path, 'diff', '--binary', 'HEAD') + '\n')
        manifest['images'][board] = item
        print(board, wns, whs, wpws)
    (ROOT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')


if __name__ == '__main__':
    main()
