#!/usr/bin/env python3
"""Stop the owned test supervisor at the user's requested qualification limit."""
import json
import os
from pathlib import Path
import signal
import time

ROOT = Path(__file__).resolve().parent
record = json.loads((ROOT/'supervisor.json').read_text())
pid = record['pid']
process = Path('/proc')/str(pid)
assert process.joinpath('stat').read_text().split()[21] == record['start_ticks']
assert str(ROOT/'finish_qualification.py') in process.joinpath('cmdline').read_bytes().decode().split('\0')
assert os.getpgid(pid) == pid
assert process.joinpath('fd/1').resolve() == ROOT/'supervisor.log'
(ROOT/'qualification-limit.json').write_text(json.dumps({
    'reason': 'User: ok, this is enough for qualification',
    'requested_unix': time.time(), 'supervisor': record,
    'pipeline_before_stop': json.loads((ROOT/'pipeline-state.json').read_text())}, indent=2)+'\n')
os.killpg(pid, signal.SIGINT)
print('Requested graceful stop of the verified qualification process group.')
