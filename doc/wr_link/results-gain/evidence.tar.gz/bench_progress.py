#!/usr/bin/env python3
"""Read existing evidence without opening either board connection."""
import json,time
from pathlib import Path
root=Path(__file__).resolve().parent
state=json.loads((root/'pipeline-state.json').read_text())
print(time.strftime('%H:%M:%S'),state)
stage=root/state['stage']
if stage.exists():
 summary=stage/'summary.json'
 if summary.exists():
  data=json.loads(summary.read_text())
  print('summary:',{k:v for k,v in data.items() if k in ['passed','error','soak_seconds']})
  for cycle in data.get('results',[]):
   print(cycle['operation'],cycle['cycle'],'passed',cycle['qualification']['passed'],'recovery',round(cycle['recovery_upper_bound_seconds'],1))
 samples=sorted(stage.rglob('samples.jsonl'),key=lambda p:p.stat().st_mtime)
 if samples:
  p=samples[-1]
  with p.open('rb') as f:
   f.seek(max(0,p.stat().st_size-16384)); lines=f.read().splitlines()
  for line in reversed(lines):
   try: data=json.loads(line)
   except json.JSONDecodeError: continue
   print('latest:',p.relative_to(root),'file_age_s',round(time.time()-p.stat().st_mtime,1))
   print({k:data[k] for k in ['elapsed','soak_elapsed','errors']})
   print({r:{k:v for k,v in (g or {}).items() if k in ['role','extension','detection','pll_locked','frequency_locked','servo']} for r,g in data['gui'].items()})
   print('slave offset',data['diagnostics']['slave']['offset_ps'],'ps; updates',data['diagnostics']['slave']['updates'])
   break
