#!/usr/bin/env python3
"""Supervise the remaining gain tests and final inspection until completion."""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
state = {'passed': False, 'started_unix': time.time()}


def run(stage, command, timeout):
    state.update(stage=stage, updated_unix=time.time())
    (ROOT/'supervisor-state.json').write_text(json.dumps(state, indent=2)+'\n')
    with (ROOT/(stage+'.log')).open('w') as log:
        subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)


try:
    run('pipeline-remaining', ['python3', str(ROOT/'qualify_upstream.py'), 'remaining'], 9000)
    run('final-inspection', ['python3', str(ROOT/'inspect_final.py')], 360)
    run('audit-final', ['python3', str(ROOT/'summarize_qualification.py'),
        '--repository', str(ROOT/'source')], 120)
    assert json.loads((ROOT/'matrix-summary.json').read_text())['complete']
    state.update(passed=True, stage='completed')
except BaseException as error:
    state.update(error=str(error), stage='failed')
    raise
finally:
    state.update(updated_unix=time.time())
    (ROOT/'supervisor-state.json').write_text(json.dumps(state, indent=2)+'\n')
