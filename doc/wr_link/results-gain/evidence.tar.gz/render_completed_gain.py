#!/usr/bin/env python3
"""Publish the observed gain results, including the user's shortened scope."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from render_gain import commands, dac_code

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'source/doc/wr_link/results-gain'


def digest(path):
    return {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}


def main():
    result = json.loads((ROOT/'gain-summary.json').read_text())
    assert result['audited'] and not result['full_matrix_completed']
    manifest = json.loads((ROOT/'manifest.json').read_text())
    OUT.mkdir(parents=True, exist_ok=True)
    for name in ['gain-summary.json', 'manifest.json', 'source-provenance.json']:
        shutil.copy2(ROOT/name, OUT/name)
    fig, axes = plt.subplots(2, 1, figsize=(10, 6), layout='constrained')
    for ax, name, label in zip(axes, ['warm-acorn-master', 'soak-spec-master'],
            ['Acorn master → SPEC slave: completed initial check', 'SPEC master → Acorn slave: observation stopped at user request']):
        rows = [json.loads(s) for s in (ROOT/name/'samples.jsonl').read_text().splitlines()]
        rows = [r for r in rows if r['soak_elapsed'] is not None]
        ax.plot([r['soak_elapsed']/60 for r in rows], [r['diagnostics']['slave']['offset_ps'] for r in rows], linewidth=.7)
        ax.set_title(label, loc='left', fontsize=10)
        ax.set_ylabel('Reported offset (ps)')
        ax.set_xlabel('Tracking time (minutes)')
        ax.grid(alpha=.2)
    fig.suptitle('SPEC DMTD ×1 gain — internal servo estimates')
    fig.savefig(OUT/'servo-offsets.svg')
    fig.savefig(OUT/'servo-offsets.png', dpi=140)
    plt.close(fig)
    files = set()
    for p in ROOT.iterdir():
        if p.name in ['render-completed.log', 'jtag-servers.json', 'evidence-replay.json', 'publication.json'] or p.name.endswith('-persistent-jtag.log'):
            continue
        if p.is_file() and p.suffix in ['.json', '.py', '.log', '.patch']:
            files.add(p)
        elif p.is_dir() and p.name.startswith(('warm-', 'soak-', 'recovery-', 'baseline-', 'failed-', 'interrupted-')):
            files.update(f for f in p.rglob('*') if f.is_file())
    for name, top in [('spec-gain', 'spec_a7_wr_nic'), ('acorn-console', 'sqrl_acorn')]:
        files.update(p for p in (ROOT/name).iterdir() if p.is_file())
        files.add(ROOT/name/'gateware'/(top+'_timing.rpt'))
    files.add(ROOT/'spec-gain/gateware/spec_a7_wr_nic.v')
    archive = OUT/'evidence.tar.gz'
    with archive.open('wb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
        for p in sorted(files):
            info = tar.gettarinfo(str(p), arcname=str(p.relative_to(ROOT)))
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ''
            with p.open('rb') as data:
                tar.addfile(info, data)
    (OUT/'evidence-files.json').write_text(json.dumps({str(p.relative_to(ROOT)): digest(p) for p in sorted(files)}, indent=2)+'\n')
    notes = (ROOT/'gain-notes-draft.md').read_text().replace('Hardware results pending. Only passing measured results will be published as qualification.\n', '')
    lines = [notes, '## Results', '',
        'Both role directions completed their initial two-minute checks. With SPEC as master, all three PCS interruption/recovery cycles and all three paired SRAM reload/recovery cycles passed. Further qualification was stopped at the user’s request: the planned 30-minute runs and Acorn-master recovery matrix were not completed for ×1. The [earlier ×2 baseline](../results-upstream/README.md) retains its separate full matrix.', '',
        '| Master → slave | Capture | Duration | Internal offset range | Standard deviation |',
        '| --- | --- | ---: | ---: | ---: |']
    labels = [('warm-acorn-master', 'Acorn → SPEC', 'Completed initial check'),
        ('warm-spec-master', 'SPEC → Acorn', 'Completed initial check'),
        ('interrupted-soak-spec-master', 'SPEC → Acorn', 'Foreground session interrupted'),
        ('soak-spec-master', 'SPEC → Acorn', 'Stopped at user request')]
    for name, direction, label in labels:
        s = result['runs'][name]; o = s['offset_ps']
        duration = s['completed_check_seconds'] or s['observed_tracking_seconds']
        lines.append(f"| {direction} | {label} | {duration:.1f} s | {o['minimum']}…{o['maximum']} ps | {o['standard_deviation']:.2f} ps |")
    lines += ['', 'The two longer captures are separate observations; they are not combined into an uninterrupted duration. Captured samples and complete UART frames after tracking began retained the expected roles, WR `IDLE / EXT_ON`, PLL/frequency lock and slave `TRACK_PHASE`. Time and updates advanced, with unchanged RX error counters. The raw replay audit passed. Stopped captures have no completed 30-minute test marker.', '',
        '![Internal servo offsets](servo-offsets.svg)', '',
        'Offsets are internal servo estimates, not independent PPS measurements or evidence of a gain-dependent accuracy improvement.', '',
        '| SPEC-master recovery | Cycles 1 / 2 / 3, upper bounds |', '| --- | ---: |']
    for op, label in [('link', 'PCS disable/enable'), ('reload', 'Both SRAM images reloaded')]:
        rows = [r for r in result['recoveries'] if r['operation'] == op]
        lines.append(f'| {label} | '+' / '.join(f"{r['recovery_upper_bound_s']:.1f} s" for r in rows)+' |')
    lines += ['', 'PCS was held down for at least five seconds, with link-down observed on both boards and both UARTs responsive. Each recovery retained at least ten seconds of phase tracking. This tests PCS reset rather than physical connector removal.', '',
        '## DAC operating points', '',
        '| SPEC role | Old ×2 DMTD code | New ×1 DMTD code | Main code with ×1 DMTD (RefClk still ×2) |', '| --- | ---: | ---: | ---: |']
    for master, role in [('acorn', 'Slave'), ('spec', 'Master')]:
        old = commands(ROOT/('baseline-'+master+'-master')/'summary.json')
        new = commands(ROOT/('warm-'+master+'-master-pll')/'spec.json')
        lines.append(f'| {role} | {dac_code(old,-1)} | {dac_code(new,-1)} | {dac_code(new,0)} |')
    s = manifest['images']['spec']
    lines += ['', 'The helper command approximately doubles, as expected when halving DAC gain. Both points remain inside the firmware tuning range. These are UART controller commands, not measured voltages. Main/helper PI coefficients were unchanged. No temperature or oscillator-tolerance sweep was performed.', '',
        '## Reproduction', '', 'Use the [USB bench guide](../../wr_link_qualification.md) with the same upstream pins and LitePCIe dependency correction. Rebuild SPEC with:', '',
        '```sh', 'python3 spec_a7_wr_nic.py --build --wr-cpu-type urv --wr-cpu-memory private --wr-read-only-storage', '```', '',
        f"Final SPEC setup/hold slack is {s['wns_ns']:+.3f}/{s['whs_ns']:+.3f} ns. The Acorn image is unchanged from the baseline. Three DAC simulations decode the actual SPI gain command and queued update for default/×1/×2; all pass, and all reject the old misspelled binding. Vivado confirms boolean gain bindings of 1 for RefClk and 0 for DMTD. The compiled UART print buffer remains 256 bytes.", '',
        'Final bench state: SPEC master at its normal main code 32768, Acorn slave. SPEC DMTD is ×1. SRAM programming and read-only firmware storage kept flash unchanged. The qualification process has stopped and physical UARTs are free.', '',
        f"[Evidence archive](evidence.tar.gz): {digest(archive)['bytes']:,} bytes, SHA-256 `{digest(archive)['sha256']}`. [File hashes](evidence-files.json) and [image manifest](manifest.json) identify the exact artifacts. Bitstreams remain local.", '',
        'Replay without hardware:', '', '```sh', 'mkdir -p /tmp/wr-gain-evidence',
        'tar -xzf doc/wr_link/results-gain/evidence.tar.gz -C /tmp/wr-gain-evidence',
        'python3 /tmp/wr-gain-evidence/audit_gain.py --repository "$PWD"', '```', '',
        'The result must contain `"audited": true` and `"full_matrix_completed": false`.', '']
    (OUT/'README.md').write_text('\n'.join(lines))
    print(OUT)


if __name__ == '__main__':
    main()
