#!/usr/bin/env python3
"""Capture final PLL/clock evidence after the complete hardware matrix."""
import fcntl,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ['PYTHONPATH']=str(ROOT/'litex')
sys.path[:0]=[str(ROOT/'litex'),str(ROOT/'source/tools')]
from wr_recover import Board

def main():
    state=json.loads((ROOT/'pipeline-state.json').read_text())
    if not state.get('passed') or state.get('stage')!='full-completed':
        raise RuntimeError('Complete the full pipeline before opening another board connection')
    lock=(ROOT/'bench.lock').open('a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    out=ROOT/'final-inspection'
    out.mkdir(exist_ok=False)
    config=json.loads((ROOT/'bench.json').read_text())
    boards={key:Board(key,cfg) for key,cfg in config.items()}
    summary={'passed':False,'boards':{}}
    try:
        for key,board in boards.items():
            board.start_server(out/(key+'-jtag.log'))
            cfg=config[key]
            with (out/(key+'-status.log')).open('w') as log:
                subprocess.run([sys.executable,str(ROOT/'source/tools/wr_link.py'),'status',
                    '--port',str(cfg['jtag_port']),'--csr-csv',cfg['csr'],
                    '--output',str(out/(key+'-status.json'))],check=True,stdout=log,stderr=subprocess.STDOUT,timeout=60)
            command=[sys.executable,str(ROOT/'source/tools/wr_link.py'),'console',
                '--port',cfg['uart'],'--output',str(out/(key+'-console')),
                '--monitor-seconds','12']
            for text in ['ver','ptp','pll stat','pll gdac 0','pll gdac -1']:
                command+=['--command',text]
            with (out/(key+'-console.log')).open('w') as log:
                subprocess.run(command,check=True,stdout=log,stderr=subprocess.STDOUT,timeout=120)
            uart=json.loads((out/(key+'-console.json')).read_text())
            if not uart['passed'] or 'PRINTF OVF' in (out/(key+'-console.uart.raw')).read_bytes().decode(errors='replace'):
                raise RuntimeError(key+': final console capture failed')
            version=next(c['response'] for c in uart['commands'] if c['command']=='ver')
            if '13527cd6' not in version:
                raise RuntimeError(key+': final firmware version differs from the reviewed build')
            status=json.loads((out/(key+'-status.json')).read_text())
            regs=status['registers']
            if key=='acorn':
                for prefix in ['refclk_mmcm_ps_gen','dmtd_mmcm_ps_gen']:
                    if regs[prefix+'_status']&2:
                        raise RuntimeError(prefix+': MMCM completion fault')
            summary['boards'][key]={'identifier':status['identifier'],
                'mmcm_registers':{k:v for k,v in regs.items() if '_mmcm_' in k}}
        summary['passed']=True
    except BaseException as error:
        summary['error']=str(error)
        raise
    finally:
        for board in boards.values():board.stop_server()
        (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
