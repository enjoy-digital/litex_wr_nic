#!/usr/bin/env python3
"""Start/stop only the persistent JTAG servers owned by this bench helper."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import signal
import socket
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / 'litex'), str(ROOT / 'source/tools')]
from wr_recover import Board


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['start', 'stop'])
    args = parser.parse_args()
    lock = (ROOT / 'bench.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    config = json.loads((ROOT / 'bench-local.json').read_text())
    state_file = ROOT / 'jtag-servers.json'
    records = json.loads(state_file.read_text()) if state_file.exists() else {}
    if args.action == 'stop':
        verified = []
        for name, record in records.items():
            pid = record['pid']
            process = Path('/proc') / str(pid)
            if not process.exists():
                continue
            argv = process.joinpath('cmdline').read_bytes().decode().split('\0')
            assert process.joinpath('stat').read_text().split()[21] == record['start_ticks'], 'PID was reused'
            assert 'litex.tools.litex_server' in argv and config[name]['jtag_config'] in argv, 'Unexpected process'
            assert os.getpgid(pid) == pid, 'Unexpected process group'
            verified.append(pid)
        for pid in verified:
            os.killpg(pid, signal.SIGTERM)
        time.sleep(1)
        for pid in verified:
            try:
                os.killpg(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        deadline = time.monotonic() + 5
        while True:
            listening = []
            for cfg in config.values():
                for port in (cfg['jtag_port'], cfg['stream_port']):
                    with socket.socket() as probe:
                        if probe.connect_ex(('127.0.0.1', port)) == 0:
                            listening.append(port)
            if not listening:
                break
            if time.monotonic() >= deadline:
                raise RuntimeError('Unmanaged or surviving servers on ports ' + str(listening))
            time.sleep(0.1)
        state_file.unlink(missing_ok=True)
        print('Owned JTAG servers stopped; USB programming interfaces released.')
        return
    if records:
        raise RuntimeError('Existing server record; use stop before starting a new pair.')
    os.environ['PYTHONPATH'] = str(ROOT / 'litex') + os.pathsep + os.environ.get('PYTHONPATH', '')
    boards = {name: Board(name, cfg) for name, cfg in config.items()}
    try:
        for name, board in boards.items():
            board.start_server(ROOT / (name + '-persistent-jtag.log'))
            pid = board.server.pid
            records[name] = {'pid': pid, 'start_ticks': (Path('/proc') / str(pid) / 'stat').read_text().split()[21],
                             'jtag_port': config[name]['jtag_port'], 'stream_port': config[name]['stream_port']}
        state_file.write_text(json.dumps(records, indent=2) + '\n')
    except BaseException:
        for board in boards.values():
            board.stop_server()
        raise
    for name, record in records.items():
        print(name + ': JTAGBone available at 127.0.0.1:' + str(record['jtag_port']))


if __name__ == '__main__':
    main()
