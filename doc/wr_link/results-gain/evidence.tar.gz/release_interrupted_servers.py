#!/usr/bin/env python3
"""Release only the verified JTAG servers orphaned by this interrupted soak."""
import fcntl
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
config = json.loads((ROOT/'bench-local.json').read_text())
records = {}
with (ROOT/'bench.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for name, pid in [('acorn', 30680), ('spec', 30690)]:
        process = Path('/proc')/str(pid)
        argv = process.joinpath('cmdline').read_bytes().decode().split('\0')
        assert 'litex.tools.litex_server' in argv and config[name]['jtag_config'] in argv
        assert str(config[name]['jtag_port']) in argv and str(config[name]['stream_port']) in argv
        assert process.joinpath('fd/1').resolve() == ROOT/('soak-spec-master-'+name+'-jtag.log')
        assert os.getpgid(pid) == pid
        records[name] = {'pid': pid, 'start_ticks': process.joinpath('stat').read_text().split()[21],
            'jtag_port': config[name]['jtag_port'], 'stream_port': config[name]['stream_port']}
    assert not (ROOT/'jtag-servers.json').exists()
    (ROOT/'jtag-servers.json').write_text(json.dumps(records, indent=2)+'\n')
subprocess.run(['python3', str(ROOT/'jtag_servers.py'), 'stop'], check=True)
