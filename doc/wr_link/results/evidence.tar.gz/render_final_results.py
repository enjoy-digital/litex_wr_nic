#!/usr/bin/env python3
"""Render and package a completed WR matrix; refuse partial qualification."""
import argparse, gzip, hashlib, json, shutil, tarfile
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repository',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parent
matrix=json.loads((root/'final-matrix-summary.json').read_text())
if not matrix['complete']:raise RuntimeError('Final qualification matrix is incomplete')
out=args.repository/'doc/wr_link/results';out.mkdir(parents=True,exist_ok=True)
for name in ['final-matrix-summary.json','manifest-tuned.json']:
 shutil.copy2(root/name,out/name)
fig,axes=plt.subplots(2,1,figsize=(10,6),sharex=True,sharey=True,layout='constrained')
for ax,name,color in zip(axes,['acorn','spec'],['#2563a6','#b45b16']):
 rows=[json.loads(line) for line in (root/('final-soak-'+name+'-master')/'samples.jsonl').read_text().splitlines()]
 rows=[r for r in rows if r['soak_elapsed'] is not None]
 ax.plot([r['soak_elapsed']/60 for r in rows],[r['diagnostics']['slave']['offset_ps'] for r in rows],lw=.7,color=color)
 ax.axhline(120,color='#888888',ls='--',lw=.7,label='±120 ps phase-correction threshold');ax.axhline(-120,color='#888888',ls='--',lw=.7)
 ax.set_title('Acorn master → SPEC slave' if name=='acorn' else 'SPEC master → Acorn slave',loc='left',fontsize=11)
 ax.set_ylabel('Reported offset (ps)');ax.grid(alpha=.18);ax.set_ylim(-135,135)
axes[0].legend(loc='upper right',fontsize=8)
axes[-1].set_xlabel('Uninterrupted tracking time (minutes)')
fig.suptitle('Internal WR servo estimates — not an independent PPS accuracy measurement',fontsize=11)
fig.savefig(out/'servo-offsets.svg');fig.savefig(out/'servo-offsets.png',dpi=160);plt.close(fig)
# Full UART bytes and coherent snapshots, including failed baseline/tuning runs.
names=['soak-acorn-master','recovery-acorn-master','soak-spec-master','tuning-baseline','tuning-main-ki1','tuning-main-300-8','tuning-main-600-16','spec-master-tuned-warm','final-cold-spec-master','final-recovery-spec-master','final-recovery-spec-master-r2','final-recovery-spec-master-r3','final-soak-spec-master','final-soak-acorn-master','final-recovery-acorn-master','final-state-acorn-master']
files=[]
for name in names:files += [p for p in (root/name).rglob('*') if p.is_file()]
for name in ['manifest.json','manifest-tuned.json','candidate-reviewed.json','final-matrix-summary.json','final-tests-77.log','final-tests-78.log','summarize_qualification.py','observe_tuning.py','observe_tuning2.py','render_final_results.py','qualify_final_images.py','qualify_final_images_resume.py','qualify_final_images_resume2.py']:
 files.append(root/name)
for name in ['acorn-qual','acorn-tuned-qual','spec-qual']:
 for p in (root/name).iterdir():
  if p.is_file() and (p.suffix in ['.patch','.csv','.config','.txt','.bin','.bram','.boot']):files.append(p)
for p in list(root.glob('final-cold-*-boot*')) + list(root.glob('final-hardware-*')):
 if p.is_file():files.append(p)
files=sorted(set(files))
archive=out/'evidence.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
 for path in files:
  info=tar.gettarinfo(str(path),arcname=str(path.relative_to(root)));info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
  with path.open('rb') as data:tar.addfile(info,data)
manifest={str(p.relative_to(root)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files}
(out/'evidence-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
lines=['# WR hardware qualification results','', 'Final qualification uses the clean rebuilt Acorn PLL profile and the unchanged SPEC image identified in [manifest-tuned.json](manifest-tuned.json). Both boards use uRV with private RAM and read-only firmware storage. The WR connection is Acorn SFP0 to SPEC-A7 J12/SFP0; host access is USB UART/JTAG only.','', '| Master → slave | Continuous tracking | Samples | Internal offset range | Standard deviation |','| --- | ---: | ---: | ---: | ---: |']
for name,label in [('acorn','Acorn → SPEC'),('spec','SPEC → Acorn')]:
 s=matrix['soaks'][name];o=s['offset_ps'];lines.append(f"| {label} | {s['soak_s']:.1f} s | {s['samples']} | {o['minimum']}…{o['maximum']} ps | {o['standard_deviation']:.2f} ps |")
lines+=['','Each run retained `IDLE / EXT_ON`, the intended PTP roles, PLL/frequency lock, and slave `TRACK_PHASE`, with advancing time/servo updates and unchanged RX error counters. Raw UART replay and snapshot audits passed.','', '![Internal servo offset estimates](servo-offsets.svg)','', 'These are the servo’s own estimates. Calibration of SFP delays/asymmetry and independent PPS accuracy measurement remain separate physical work. The free-running master epoch is not traceable UTC/TAI.','', '| Master | Interruption | Recovery upper bounds, cycles 1 / 2 / 3 |','| --- | --- | ---: |']
for name,label in [('acorn','Acorn'),('spec','SPEC')]:
 for op,title in [('link','PCS disable/enable'),('reload','Both boards SRAM reloaded')]:
  rows=[r for r in matrix['recoveries'][name]['cycles'] if r['operation']==op]
  lines.append(f"| {label} | {title} | "+' / '.join(f"{r['recovery_upper_bound_s']:.1f} s" for r in rows)+' |')
lines+=['','Each PCS interruption held the link down for at least five seconds, proved link-down on both boards, and captured a physical UART version response from each while down. uRV debug briefly pauses the slave CPU for the PCS register transactions; this is not a physical cable-removal test. Each SRAM reload matched the qualified image hashes. Every recovery finished within five minutes and then tracked for at least ten seconds.','', 'The final state verification leaves Acorn master (volatile main trim 35000) and SPEC slave. Flash was not programmed; automatic PHY calibration remained in RAM.','', 'Regression validation: all 78 tests passed after the PLL and UART recovery fixes (68.27 seconds). Both final FPGA builds meet timing: Acorn WNS +0.031 ns / WHS +0.053 ns; SPEC WNS +0.016 ns / WHS +0.053 ns.','', 'The archive includes the failed reverse baseline and all PLL tuning comparisons as well as the completed tests. The original-image Acorn-master qualification is retained separately from the final-image matrix. FPGA bitstreams and large Vivado reports remain in the local build directory; their hashes are in the manifests.','', f"[Raw evidence archive](evidence.tar.gz): {archive.stat().st_size:,} bytes; SHA-256 `{hashlib.sha256(archive.read_bytes()).hexdigest()}`. [Per-file hashes](evidence-files.json) and [matrix audit](final-matrix-summary.json) accompany it.",'']
lines += ['## Replay the audit', '', 'From the repository root, extract the evidence into a new directory and run the included standard-library audit against this checkout’s `tools/wr_status.py`:', '', '```sh', 'mkdir -p /tmp/wr-qualification-evidence', 'tar -xzf doc/wr_link/results/evidence.tar.gz -C /tmp/wr-qualification-evidence', 'python3 /tmp/wr-qualification-evidence/summarize_qualification.py \\', '    --repository "$PWD" --manifest manifest-tuned.json \\', '    --spec-soak final-soak-spec-master --acorn-soak final-soak-acorn-master \\', '    --recovery-prefix final-recovery- \\', '    --spec-recovery final-recovery-spec-master-r3 \\', '    --final-state final-state-acorn-master --output replayed-matrix.json', '```', '', 'The resulting matrix must have `"complete": true`. This replay needs no FPGA access. Follow the [qualification guide](../../wr_link_qualification.md) to reproduce the hardware tests.', '']
(out/'README.md').write_text('\n'.join(lines))
print(out);print('Archive bytes',archive.stat().st_size)
