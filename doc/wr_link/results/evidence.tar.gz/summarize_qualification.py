#!/usr/bin/env python3
"""Audit captured qualification results and replay physical UART frames."""
import argparse, hashlib, importlib.util, json, math, statistics
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repository',type=Path,required=True)
parser.add_argument('--evidence',type=Path,default=Path(__file__).resolve().parent)
parser.add_argument('--spec-soak', default='soak-spec-master')
parser.add_argument('--acorn-soak', default='soak-acorn-master')
parser.add_argument('--recovery-prefix', default='recovery-')
parser.add_argument('--spec-recovery', default=None)
parser.add_argument('--manifest', default='manifest.json')
parser.add_argument('--final-state', default='final-acorn-master')
parser.add_argument('--output', default='matrix-summary.json')
args=parser.parse_args()
spec=importlib.util.spec_from_file_location('wr_status',args.repository/'tools/wr_status.py')
status=importlib.util.module_from_spec(spec);spec.loader.exec_module(status)
manifest=json.loads((args.evidence/args.manifest).read_text())
result={'complete':False,'soaks':{},'recoveries':{}}
for name in ['acorn','spec']:
 path=args.evidence/(args.spec_soak if name=='spec' else args.acorn_soak)
 if not (path/'summary.json').exists():continue
 summary=json.loads((path/'summary.json').read_text())
 if not summary.get('passed'):
  result['soaks'][name]={'passed':False,'path':path.name,'error':summary.get('error')}
  continue
 samples=[json.loads(line) for line in (path/'samples.jsonl').read_text().splitlines()]
 samples=[s for s in samples if s['soak_elapsed'] is not None]
 errors=[]
 if summary.get('soak_seconds',0)<1800:errors.append('soak shorter than 1800 seconds')
 if summary.get('acquired_after',float('inf'))>300:errors.append('acquisition exceeded 300 seconds')
 previous=None
 for sample in samples:
  gui=sample['gui'];diags=sample['diagnostics']
  errors+=sample['errors']
  errors+=status.qualification_errors(gui['master'],gui['slave'],diags['master'],diags['slave'],max(frame['received'] for frame in gui.values()))
  for role in ['master','slave']:
   if diags[role]['raw'][10]>=1_000_000_000:errors.append(role+': invalid nsec')
   if previous and diags[role]['tai_ns']<previous[role]['tai_ns']:errors.append(role+': time moved backwards')
  if previous and any(diags[role]['rx_errors']!=previous[role]['rx_errors'] for role in diags):errors.append('RX error counter changed')
  if previous and (diags['slave']['updates']-previous['slave']['updates'])&0xffffffff>0x80000000:errors.append('updates moved backwards')
  previous=diags
 offsets=[s['diagnostics']['slave']['offset_ps'] for s in samples]
 item={'passed':not errors,'audit_errors':sorted(set(errors)),'acquired_after_s':summary['acquired_after'],'soak_s':summary['soak_seconds'],'samples':len(samples),'offset_ps':{'minimum':min(offsets),'maximum':max(offsets),'mean':statistics.mean(offsets),'standard_deviation':statistics.pstdev(offsets)},'servo_updates_advanced':(samples[-1]['diagnostics']['slave']['updates']-samples[0]['diagnostics']['slave']['updates'])&0xffffffff,'maximum_snapshot_time_difference_s':max(abs(s['diagnostics']['master']['tai_ns']-s['diagnostics']['slave']['tai_ns']) for s in samples)/1e9,'raw_uart':{}}
 for role in ['master','slave']:
  raw=(path/(role+'.uart.raw')).read_bytes();screen=status.WRScreen();frames=screen.feed(raw,now=0)
  def good(f):return f['role']==role.upper() and f['extension']=='IDLE' and f['detection']=='EXT_ON' and f['pll_locked'] and f['frequency_locked'] and (role=='master' or f['servo']=='TRACK_PHASE')
  first=next((i for i,f in enumerate(frames) if good(f)),None)
  bad=[] if first is None else [f for f in frames[first:] if not good(f)]
  item['raw_uart'][role]={'sha256':hashlib.sha256(raw).hexdigest(),'frames':len(frames),'first_tracking_frame':first,'nontracking_frames_after_first':len(bad)}
  if first is None or bad:item['passed']=False
 result['soaks'][name]=item
for name in ['acorn','spec']:
 path=args.evidence/(args.spec_recovery if name=='spec' and args.spec_recovery else args.recovery_prefix+name+'-master')/'summary.json'
 if not path.exists():continue
 summary=json.loads(path.read_text());rows=[];evidence_errors=[]
 for cycle in summary.get('results',[]):
  if cycle['operation']=='reload':
   loads=cycle.get('reloads',[])
   if sorted(b['board'] for b in loads)!=['acorn','spec']:evidence_errors.append('reload did not include both boards')
   for board in loads:
    expected={v['sha256'] for k,v in manifest['images'][board['board']]['files'].items() if k.endswith(('.bit','.bin')) and '/gateware/' in k}
    if not board.get('passed') or board['sha256'] not in expected:evidence_errors.append('reload image differs from manifest')
  elif cycle['operation']=='link':
   interruption=cycle.get('interruption',{})
   if not interruption.get('passed'):evidence_errors.append('PCS interruption failed')
   if not any(len(sample)==2 and all(not d['link'] for d in sample.values()) for sample in interruption.get('samples',[])):evidence_errors.append('link down was not observed on both boards')
   if interruption.get('enabled_unix',0)-interruption.get('disabled_unix',0)<5:evidence_errors.append('PCS hold shorter than five seconds')
   for board in ['acorn','spec']:
    if 'WR Core build:' not in interruption.get(board+'_during_down_version',''):evidence_errors.append('UART did not respond during link down')
  rows.append({'operation':cycle['operation'],'cycle':cycle['cycle'],'passed':cycle['qualification']['passed'],'recovery_upper_bound_s':cycle['recovery_upper_bound_seconds'],'tracking_observed_s':cycle['qualification']['soak_seconds']})
 result['recoveries'][name]={'passed':summary.get('passed',False) and not evidence_errors and all(sorted(row['cycle'] for row in rows if row['operation']==op)==[1,2,3] for op in ['link','reload']) and all(row['passed'] and row['recovery_upper_bound_s']<=300 and row['tracking_observed_s']>=10 for row in rows),'cycles':rows,'audit_errors':sorted(set(evidence_errors)),'error':summary.get('error')}
final=args.evidence/args.final_state/'summary.json'
result['final_acorn_master_passed']=final.exists() and json.loads(final.read_text()).get('passed',False)
result['complete']=all(name in result[section] and result[section][name]['passed'] for name in ['acorn','spec'] for section in ['soaks','recoveries']) and result['final_acorn_master_passed']
(args.evidence/args.output).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
