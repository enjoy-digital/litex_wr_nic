#!/usr/bin/env python3
"""Final-image bench sequence. Each stage stops on its first failure."""
import hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/tmp/wr-link-20260911')
sys.path.insert(0,str(REPO/'tools'))
from wr_recover import Board
config=json.loads((ROOT/'bench-tuned.json').read_text())
state={'passed':False,'stage':'starting'}
def update(stage):
 state['stage']=stage
 (ROOT/'final-pipeline-state.json').write_text(json.dumps(state,indent=2)+'\n')
 print(stage,flush=True)
def qualify(name,master,duration,configure=False,trim=None,reload=False):
 update(name)
 boards={key:Board(key,cfg) for key,cfg in config.items()}
 slave=next(key for key in boards if key!=master)
 try:
  for key,board in boards.items():
   if reload:board.reload(ROOT/(name+'-'+key+'-boot'))
   else:board.start_server(ROOT/(name+'-'+key+'-jtag.log'))
  cmd=[sys.executable,str(REPO/'tools/wr_qualify.py'),'--duration',str(duration),'--output',str(ROOT/name)]
  if configure:cmd+=['--configure']
  for role,key in [('master',master),('slave',slave)]:
   cfg=config[key];cmd+=['--'+role+'-uart',cfg['uart'],'--'+role+'-jtag',str(cfg['jtag_port']),'--'+role+'-csr',cfg['csr']]
  if trim is not None:cmd+=['--master-trim',str(trim)]
  with (ROOT/(name+'.log')).open('w') as log:subprocess.run(cmd,check=True,stdout=log,stderr=subprocess.STDOUT,timeout=duration+420)
 finally:
  for board in boards.values():board.stop_server()
 if not json.loads((ROOT/name/'summary.json').read_text())['passed']:raise RuntimeError(name+' did not pass')
def recovery(master,trim=None):
 name='final-recovery-'+master+'-master'+('-r3' if master=='spec' else '');update(name)
 cmd=[sys.executable,str(REPO/'tools/wr_recover.py'),'--config',str(ROOT/'bench-tuned.json'),'--master',master,'--operation','both','--cycles','3','--output',str(ROOT/name)]
 if trim is not None:cmd+=['--master-trim',str(trim)]
 with (ROOT/(name+'.log')).open('w') as log:subprocess.run(cmd,check=True,stdout=log,stderr=subprocess.STDOUT,timeout=2700)
 if not json.loads((ROOT/name/'summary.json').read_text())['passed']:raise RuntimeError(name+' did not pass')
try:
 # This marker is written only after the root agent reviews the completed
 # clean build, positive timing and final image/firmware/CSR hashes.
 reviewed=json.loads((ROOT/'candidate-reviewed.json').read_text())
 if not reviewed['passed']:raise RuntimeError('Candidate build review failed')
 manifest=json.loads((ROOT/reviewed['manifest']).read_text())
 for key,cfg in config.items():
  for item in ['bitstream','csr']:
   path=Path(cfg[item]);expected=manifest['images'][key]['files'][str(path.relative_to(ROOT))]['sha256']
   if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:raise RuntimeError(key+' '+item+' hash changed')
 update('waiting-for-warm-test')
 deadline=time.monotonic()+900
 while not (ROOT/'spec-master-tuned-warm/summary.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('Warm test did not finish')
  time.sleep(5)
 warm=json.loads((ROOT/'spec-master-tuned-warm/summary.json').read_text())
 if not warm['passed']:raise RuntimeError('Warm tuning test failed')
 if not json.loads((ROOT/'final-cold-spec-master/summary.json').read_text())['passed']:raise RuntimeError('Cold test did not pass')
 recovery('spec')
 qualify('final-soak-spec-master','spec',1800)
 qualify('final-soak-acorn-master','acorn',1800,configure=True,trim=35000)
 recovery('acorn',35000)
 qualify('final-state-acorn-master','acorn',60)
 state['passed']=True;update('completed')
except BaseException as error:
 state['error']=str(error);update('failed');raise
