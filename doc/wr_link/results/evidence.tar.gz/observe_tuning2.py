#!/usr/bin/env python3
"""Bench experiment: collect failures without labeling a run as qualification."""
import sys, json, time, statistics, signal
signal.signal(signal.SIGINT, signal.default_int_handler)
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/tmp/wr-link-20260911/tools')
from wr_link import Console
from wr_status import WRScreen, diagnostic_snapshot, qualification_errors
from litex import RemoteClient
cfg=json.loads((ROOT/'bench.json').read_text())
experiments=[('main-300-8',['pll gain 0 0 -300 -8 12'],180),('main-600-16',['pll gain 0 0 -600 -16 12'],180)]
for name,commands,duration in experiments:
 out=ROOT/('tuning-'+name);out.mkdir(exist_ok=False)
 consoles={};buses={};screens={};offsets={};rows=[]
 try:
  for role,key in [('master','spec'),('slave','acorn')]:
   c=consoles[role]=Console(cfg[key]['uart'],out/role);c.connect();c.command('verbose 0')
   if role=='slave':
    for command in commands:c.command(command)
    c.command('pll stat')
   bus=buses[role]=RemoteClient(port=cfg[key]['jtag_port'],csr_csv=cfg[key]['csr'],timeout=5,raise_on_timeout=True);bus.open()
   screens[role]=WRScreen();offsets[role]=len(c.buffer);c.send('gui\r')
  start=time.monotonic();report=start
  with (out/'samples.jsonl').open('w',buffering=1) as log, ThreadPoolExecutor(2) as pool:
   while time.monotonic()-start<duration:
    frames={}
    for role,c in consoles.items():
     end=len(c.buffer);frames[role]=screens[role].feed(bytes(c.buffer[offsets[role]:end]),now=c.last_received or start);offsets[role]=end
    pending={r:pool.submit(diagnostic_snapshot,b) for r,b in buses.items()};diags={r:f.result() for r,f in pending.items()}
    now=time.monotonic();gui={r:s.latest for r,s in screens.items()}
    errors=qualification_errors(gui['master'],gui['slave'],diags['master'],diags['slave'],now)
    row=dict(elapsed=now-start,errors=errors,diagnostics=diags,gui=gui,frames=frames);rows.append(row);log.write(json.dumps(row)+'\n')
    if now-report>30:
     print(name,round(now-start,1),'state',diags['slave']['servo_state'],'offset',diags['slave']['offset_ps'],'errors',errors,flush=True);report=now
    time.sleep(.1)
 finally:
  for c in consoles.values():
   try:
    n=len(c.buffer);c.send('q');c.prompt(n);c.command('pll stat')
   except Exception as e:print(e,flush=True)
   c.close()
  for bus in buses.values():bus.close()
  offsets_ps=[r['diagnostics']['slave']['offset_ps'] for r in rows if r['elapsed']>30]
  result=dict(qualification=False,commands=commands,seconds=time.monotonic()-start,seconds_requested=duration,samples=len(rows),error_samples=sum(bool(r['errors']) for r in rows),offset_ps=dict(min=min(offsets_ps),max=max(offsets_ps),stdev=statistics.pstdev(offsets_ps)))
  (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(name,result,flush=True)
